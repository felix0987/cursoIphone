//
//  Opcion2.swift
//  epParcial
//
//  Created by user209909 on 28/05/22.
//



import UIKit

class Opcion2: UIViewController {
    
    @IBAction private func button(_ sender:Any){
        navigationController?.popViewController(animated: true)
 }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
